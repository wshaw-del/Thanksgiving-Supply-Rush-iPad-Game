THANKSGIVING SUPPLY RUSH — RESTORED MULTIPLAYER GAME + ALL 75 PUZZLES

This is the repository ROOT contents. It is not a /samples game.

FILES:
  index.html        Restored original multiplayer, team and solo station logic
  puzzles.json      All 75 puzzle titles, themes, image paths and 3 touch zones
  puzzles/          Exactly 150 square JPEG images named p01a.jpg–p75b.jpg
  VALIDATION.txt    Notes on recovered sources and remaining checks

UPLOAD:
  1. Make a backup of your current GitHub repository.
  2. On GitHub, replace ROOT index.html and upload puzzles.json to repository root.
  3. Upload the contents of puzzles/ to a folder literally named puzzles in the repository root.
  4. Do not upload this package into /samples and do not use a batch test index.html.
  5. Go to Settings > Pages and confirm branch main / (root) is published.
  6. Open your Github Pages address after a refresh. Test solo first, then both iPads.

TROUBLESHOOTING:
  If no images load: confirm paths like /puzzles/p01a.jpg and /puzzles.json exist.
  Clear Safari cache/force reload for a new version. Check that your GitHub Pages page is enabled.
  PeerJS connection requires internet on both iPads and may fail on restrictive networks.

IMPORTANT:
  31–35 and 61–65 were previously supplied only as a combined picture without
  validated touch metadata. Their touch zones in this package are provisional.
  The other targets were drawn from the previous batch test files, not retested
  physically on this device. Always test on the iPads before your event.
